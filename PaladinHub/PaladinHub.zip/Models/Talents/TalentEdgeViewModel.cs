﻿namespace PaladinHub.Models.Talents
{
	public class TalentEdgeViewModel
	{
		public string FromId { get; set; } = string.Empty;
		public string ToId { get; set; } = string.Empty;
		public string FromShape { get; set; } = "circle";
		public string ToShape { get; set; } = "circle";
	}
}
