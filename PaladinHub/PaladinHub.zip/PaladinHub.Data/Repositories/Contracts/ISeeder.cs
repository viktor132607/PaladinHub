﻿namespace PaladinHub.Data.Repositories.Contracts
{
	public interface ISeeder
	{
		Task SeedAsync();
	}
}
