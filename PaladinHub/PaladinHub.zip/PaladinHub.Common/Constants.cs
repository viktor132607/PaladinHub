﻿namespace PaladinHub.Common
{
	public static class Constants
	{
		public static class Cart
		{
			public const int TtlHours = 2;
			public const string RedisPrefix = "cart:";
		}
	}
}
