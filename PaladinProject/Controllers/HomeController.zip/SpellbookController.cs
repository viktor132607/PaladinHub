﻿using Microsoft.AspNetCore.Mvc;
using PaladinProject.Models;
using TalentBuilder.Models;
using static System.Net.WebRequestMethods;

namespace PaladinProject.Controllers
{
	public class SpellbookController : Controller
	{

	};
}
