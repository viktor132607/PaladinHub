﻿using Microsoft.AspNetCore.Mvc;
using TalentBuilder.Models;

namespace PaladinProject.Controllers
{
	public class TalentsController : Controller
	{

	}
}
