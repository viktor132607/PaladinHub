using Microsoft.AspNetCore.Mvc;
using PaladinProject.Models;

namespace PaladinProject.Controllers
{
    [Route("Items")]
    public class ItemsController : Controller
    {
        private readonly ItemService _itemService;

        public ItemsController()
        {
            _itemService = new ItemService();
        }

        [HttpGet("{spec}/Consumables")]
        public IActionResult Consumables(string spec)
        {
            var allItems = _itemService.GetAllItems();
            return View($"~/Views/{spec}/Consumables.cshtml", allItems);
        }
    }
}
